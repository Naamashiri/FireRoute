package fireroute.api;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * Turns exceptions escaping any controller into HTTP responses.
 *
 * It lives outside the controllers so that no controller needs a try/catch and
 * every endpoint — including ones written later — reports failures the same way.
 * Controllers describe what an endpoint does; this describes how the API admits
 * that something went wrong.
 *
 * Extending ResponseEntityExceptionHandler is not decoration. Spring already
 * answers an unknown path with 404 and a wrong verb with 405 by raising its own
 * exceptions, and a bare @ExceptionHandler(Exception.class) here would intercept
 * those and rebrand every one of them as a 500. The base class supplies the
 * correct handler for each, and Spring prefers the most specific match, so the
 * catch-all below only ever sees what nothing else claimed.
 *
 * Responses use ProblemDetail, Spring's implementation of RFC 7807 — the
 * standard shape for an HTTP error body — rather than an error type invented
 * here.
 */
@RestControllerAdvice
public class ApiExceptionHandler extends ResponseEntityExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(ApiExceptionHandler.class);

    /**
     * Invalid input: an unknown junction id, a blank id, a negative fearFactor.
     * The caller can fix all of these by sending a different request, which is
     * exactly what 400 means — so the exception's own message is safe and useful
     * to pass back.
     */
    @ExceptionHandler(IllegalArgumentException.class)
    public ProblemDetail handleInvalidRequest(IllegalArgumentException exception) {
        log.debug("Rejected request: {}", exception.getMessage());

        ProblemDetail problem = ProblemDetail.forStatusAndDetail(
                HttpStatus.BAD_REQUEST,
                exception.getMessage()
        );
        problem.setTitle("Invalid route request");
        return problem;
    }

    /**
     * The safety net: anything not recognised above is a defect on this side, so
     * it is a 500 and the client is told nothing beyond that. The details go to
     * the log, where they are useful, instead of into the response, where a stack
     * trace would leak class names and internal structure to a stranger.
     */
    @ExceptionHandler(Exception.class)
    public ProblemDetail handleUnexpected(Exception exception) {
        log.error("Unhandled exception while serving a request", exception);

        ProblemDetail problem = ProblemDetail.forStatusAndDetail(
                HttpStatus.INTERNAL_SERVER_ERROR,
                "The request could not be completed."
        );
        problem.setTitle("Internal error");
        return problem;
    }
}
