package fireroute.api.controller;

import fireroute.application.AlertReading;
import fireroute.api.dto.AlertStatusResponse;
import fireroute.domain.alert.AlertState;
import fireroute.infrastructure.alert.SimulatedAlertSource;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Raises and clears an alert by hand, so the feature can be demonstrated
 * without waiting for a real one.
 *
 * It is the one place the api layer touches infrastructure, which is why it
 * sits in a class of its own behind a property rather than alongside the real
 * endpoints: switching the property off removes the bean, and with it the
 * endpoint. Nothing else in the api layer depends on a source implementation.
 *
 * The change is applied to the source rather than to AlertState, so the next
 * poll carries it through the same path a real alert takes. The response
 * therefore still shows the OLD state — the new one appears within one poll
 * interval.
 */
@RestController
@RequestMapping("/api")
@ConditionalOnProperty(
        name = "fireroute.alerts.simulation-enabled",
        havingValue = "true",
        matchIfMissing = true
)
public class AlertSimulationController {

    private final SimulatedAlertSource simulatedAlertSource;
    private final AlertState alertState;

    public AlertSimulationController(
            SimulatedAlertSource simulatedAlertSource,
            AlertState alertState
    ) {
        if (simulatedAlertSource == null || alertState == null) {
            throw new IllegalArgumentException("dependencies must not be null");
        }
        this.simulatedAlertSource = simulatedAlertSource;
        this.alertState = alertState;
    }

    @PostMapping("/alerts/simulate")
    public AlertStatusResponse simulate(@RequestParam boolean active) {
        simulatedAlertSource.set(active ? AlertReading.ACTIVE : AlertReading.QUIET);

        return new AlertStatusResponse(
                alertState.getAreaId(),
                alertState.isAlertActive()
        );
    }
}
