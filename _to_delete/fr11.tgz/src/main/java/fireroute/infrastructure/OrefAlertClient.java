package fireroute.infrastructure;

public class OrefAlertClient {

}
